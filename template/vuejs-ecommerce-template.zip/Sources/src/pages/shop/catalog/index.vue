<script lang="ts">

import Page from './_slug.vue'

export default Page

</script>
