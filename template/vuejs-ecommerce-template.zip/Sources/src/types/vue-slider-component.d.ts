declare module 'vue-slider-component/dist-css/vue-slider-component.umd.min.js' {
    import VueSlider from 'vue-slider-component'

    // noinspection JSDuplicatedDeclaration,JSUnusedGlobalSymbols
    export default VueSlider
}
