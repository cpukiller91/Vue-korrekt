export interface IReview {
    avatar: string;
    author: string;
    rating: number;
    date: string;
    text: string;
}
