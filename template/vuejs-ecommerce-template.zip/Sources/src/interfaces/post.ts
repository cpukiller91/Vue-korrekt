export interface IPost {
    id: number;
    title: string;
    image: string;
    date: string;
    categories: string[];
}
