export interface IBrand {
    slug: string;
    name: string;
    image?: string;
}
