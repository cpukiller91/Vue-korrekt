export interface ICustomFields {
    [key: string]: any;
}
