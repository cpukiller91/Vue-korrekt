export default {
    name: 'Stroyka',
    fullName: 'Stroyka - Tools Store Vue eCommerce Template',
    url: 'https://themeforest.net/item/stroyka-tools-store-vuejs-ecommerce-template/27967713',
    author: {
        name: 'Kos',
        profile_url: 'https://themeforest.net/user/kos9'
    },
    contacts: {
        address: '715 Fake Street, New York 10021 USA',
        email: 'stroyka@example.com',
        phone: '(800) 060-0730'
    }
}
