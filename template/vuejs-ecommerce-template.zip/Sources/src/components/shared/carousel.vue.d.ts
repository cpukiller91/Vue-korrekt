declare module '~/components/shared/carousel.vue' {
    import Carousel from '~/components/shared/carousel'

    // noinspection JSDuplicatedDeclaration,JSUnusedGlobalSymbols
    export default Carousel
}
