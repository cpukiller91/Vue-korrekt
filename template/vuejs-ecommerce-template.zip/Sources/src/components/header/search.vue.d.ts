declare module '~/components/header/search.vue' {
    import Search from '~/components/header/search'

    // noinspection JSDuplicatedDeclaration,JSUnusedGlobalSymbols
    export default Search
}
