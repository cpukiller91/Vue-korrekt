declare module '~/components/header/indicator.vue' {
    import Indicator from '~/components/header/indicator'

    // noinspection JSDuplicatedDeclaration,JSUnusedGlobalSymbols
    export default Indicator
}
