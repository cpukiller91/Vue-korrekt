declare module '~/components/header/departments.vue' {
    import Departments from '~/components/header/departments'

    // noinspection JSDuplicatedDeclaration,JSUnusedGlobalSymbols
    export default Departments
}
