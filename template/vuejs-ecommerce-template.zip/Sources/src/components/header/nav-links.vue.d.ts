declare module '~/components/header/nav-links.vue' {
    import NavLinks from '~/components/header/nav-links'

    // noinspection JSDuplicatedDeclaration,JSUnusedGlobalSymbols
    export default NavLinks
}
